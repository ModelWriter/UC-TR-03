**ClaferIG Version 0.3.6.1 released on Jul 08, 2014**

[Release](https://github.com/gsdlab/claferIG/pull/20)

**ClaferIG Version 0.3.6 released on May 23, 2014**

[Release](https://github.com/gsdlab/claferIG/pull/19)

**ClaferIG Version 0.3.5 released on January 20, 2014**

[Release](https://github.com/gsdlab/claferIG/pull/17)

[New features and bug fixes](http://gsd.uwaterloo.ca:8888/questions/scope:all/sort:activity-desc/tags:v0.3.5,claferig/page:1/)

**ClaferIG Version 0.3.4 released on September 20, 2013**

[New features and bug fixes](http://gsd.uwaterloo.ca:8888/questions/scope:all/sort:activity-desc/tags:v0.3.4,claferig/page:1/)

**ClaferIG Version 0.3.3 released on August 14, 2013**

[Release](https://github.com/gsdlab/claferIG/pull/12)

[New features and bug fixes](http://gsd.uwaterloo.ca:8888/questions/scope:all/sort:activity-desc/tags:v0.3.3,claferig/page:1/)

**ClaferIG Version 0.3.2 released on April 11, 2013**

[New features and bug fixes](http://gsd.uwaterloo.ca:8888/questions/scope:all/sort:activity-desc/tags:v0.3.2,claferig/page:1/)

**ClaferIG Version 0.3.1 released on October 17, 2012**

[New features and bug fixes](http://gsd.uwaterloo.ca:8888/questions/scope:all/sort:activity-desc/tags:v0.3.1,claferig/page:1/)

**ClaferIG Version 0.3 released on July 17, 2012**

This was the first release of Clafer Instance Generator and included all code since the beginning of the project.

[New features and bug fixes](http://gsd.uwaterloo.ca:8888/questions/scope:all/sort:activity-desc/tags:v0.3,claferig/page:1/)

Undocumented features - See the `README.md`.





